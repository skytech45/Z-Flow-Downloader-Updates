from __future__ import annotations

import asyncio
import errno
import hashlib
import hmac
import json
import os
import re
import time
import uuid
from stat import S_ISLNK, S_ISREG
from asyncio import TaskGroup, CancelledError
from contextlib import suppress
from dataclasses import field, dataclass
from email.utils import parsedate_to_datetime
from pathlib import Path
from struct import unpack, pack

from loguru import logger

from app.checksum import parseTrustedChecksum, toChecksum
from app.client import buildClient, toEmulation
from app.config.cfg import cfg
from app.models.task import Task, TaskError, TaskStep, TaskStatus, SpecialFileSize
from app.platform.sysio import ftruncate, pwrite
from app.services.diagnostics import capture_http_response, record_download_failure

STREAM_READ_TIMEOUT = 30
SPLIT_START_INTERVAL = 0.2
MAX_SUBWORKERS = 256
PERMANENT_STATUS = frozenset({400, 401, 403, 404, 405, 410, 451})
TRANSIENT_STATUS = frozenset({408, 425, 429, 500, 502, 503, 504})
MAX_TRANSFER_ATTEMPTS = 4
BASE_RETRY_DELAY = 0.5
DISK_SPACE_ERRNO = frozenset({errno.ENOSPC, errno.EDQUOT, 39, 112})
FATAL_IO_ERRNO = DISK_SPACE_ERRNO | frozenset({errno.EROFS, errno.EIO})


class PermanentDownloadError(Exception):
    def __init__(self, status: int):
        super().__init__(f"HTTP {status}")
        self.status = status


class TransientHttpStatusError(Exception):
    def __init__(self, status: int):
        super().__init__(f"HTTP {status}")
        self.status = status


def _raiseUnexpectedHttpStatus(status: int) -> None:
    if status in TRANSIENT_STATUS:
        raise TransientHttpStatusError(status)
    raise PermanentDownloadError(status)


class RangeNotSupportedError(Exception):
    pass


class InvalidTransferResponseError(Exception):
    pass


def _parseContentRange(response) -> tuple[int, int, int | None]:
    value = response.headers.get("content-range", b"")
    if isinstance(value, bytes):
        value = value.decode("ascii", errors="replace")
    match = re.fullmatch(r"bytes\s+(\d+)-(\d+)/(\d+|\*)", str(value).strip(), re.IGNORECASE)
    if not match:
        raise InvalidTransferResponseError("missing or malformed Content-Range")
    start, end = int(match.group(1)), int(match.group(2))
    total = None if match.group(3) == "*" else int(match.group(3))
    if start > end or (total is not None and total <= end):
        raise InvalidTransferResponseError("inconsistent Content-Range")
    return start, end, total


def _parseUnsatisfiedContentRange(response) -> int | None:
    value = response.headers.get("content-range", b"")
    if isinstance(value, bytes):
        value = value.decode("ascii", errors="replace")
    match = re.fullmatch(r"bytes\s+\*/(\d+)", str(value).strip(), re.IGNORECASE)
    return int(match.group(1)) if match else None


@dataclass(frozen=True)
class HttpValidator:
    kind: str
    value: str


def _headerValue(headers, name: str) -> str:
    value = headers.get(name, b"")
    if isinstance(value, bytes):
        return value.decode("latin-1").strip()
    return str(value).strip()


def _httpValidator(headers) -> HttpValidator | None:
    etag = _headerValue(headers, "etag")
    if (etag and not etag[:2].lower() == "w/"
            and re.fullmatch(r'"[\x21\x23-\x7e\x80-\xff]*"', etag)):
        return HttpValidator("etag", etag)

    lastModified = _headerValue(headers, "last-modified")
    if lastModified:
        try:
            parsedate_to_datetime(lastModified)
        except (TypeError, ValueError, OverflowError):
            return None
        return HttpValidator("last-modified", lastModified)
    return None


def _matchesValidator(response, validator: HttpValidator | None) -> bool:
    if validator is None:
        return True
    value = _headerValue(response.headers, validator.kind)
    return not value or value == validator.value


def _hasMatchingValidator(response, validator: HttpValidator | None) -> bool:
    if validator is None:
        return False
    return _headerValue(response.headers, validator.kind) == validator.value


def _writeFully(fd: int, data: bytes, offset: int) -> None:
    writtenTotal = 0
    while writtenTotal < len(data):
        written = pwrite(fd, data[writtenTotal:], offset + writtenTotal)
        if written <= 0:
            raise OSError(errno.EIO, "positional write made no progress")
        writtenTotal += written


def _boundedSubworkerCount(value: object) -> int:
    try:
        return max(1, min(int(value), MAX_SUBWORKERS))
    except (TypeError, ValueError):
        return 1


def _ioTaskError(error: OSError, *, preparing: bool = False) -> TaskError:
    if error.errno in DISK_SPACE_ERRNO:
        return TaskError("磁盘空间不足")
    if preparing:
        return TaskError("无法准备下载文件")
    return TaskError("发生了意外错误：{detail}", detail=str(error))


@dataclass
class HttpSubworker:
    index: int
    start: int
    end: int
    receivedBytes: int = 0
    lastDiagnostics: dict = field(default_factory=dict, repr=False)
    consecutiveFailures: int = field(default=0, repr=False)

    @property
    def position(self) -> int:
        return self.start + self.receivedBytes


@dataclass(kw_only=True, eq=False)
class HttpTask(Task):
    packId: str = "http"
    canEdit = True

    def canReuseProgress(self, newTask: Task) -> bool:
        return (
            isinstance(newTask, HttpTask)
            and self.fileSize > 0
            and self.fileSize == newTask.fileSize
        )

    def saveMetadata(self) -> None:
        for step in self.steps:
            if isinstance(step, HttpTaskStep):
                step.saveExpectedChecksum()

    def deleteFiles(self) -> None:
        for step in self.steps:
            if isinstance(step, HttpTaskStep):
                step.loadExpectedChecksum()
        super().deleteFiles()


@dataclass(kw_only=True)
class HttpTaskStep(TaskStep):
    url: str = ""
    fileSize: int = 0
    headers: dict[str, str] = field(default_factory=dict)
    clientProfile: str = ""
    userAgent: str = ""
    subworkerCount: int = 8
    canUseRangeRequests: bool = False
    httpByteOffset: int = 0
    lastModified: str = ""
    isAccelerated: bool = False
    subworkers: list[HttpSubworker] = field(default_factory=list, repr=False)
    _activeValidator: HttpValidator | None = field(default=None, init=False, repr=False)
    _expectedChecksumAlgorithm: str = field(default="", init=False, repr=False)
    _expectedChecksumValue: str = field(default="", init=False, repr=False)
    _invalidChecksumEntry: bool = field(default=False, init=False, repr=False)
    _fallbackStagePath: Path | None = field(default=None, init=False, repr=False)
    _outputFingerprint: tuple | None = field(default=None, init=False, repr=False)
    _fallbackTargetFingerprint: tuple | None = field(default=None, init=False, repr=False)
    _remoteSizeChangedWithoutValidator: bool = field(default=False, init=False, repr=False)
    _rangeFallbackActive: bool = field(default=False, init=False, repr=False)

    @property
    def canPause(self) -> bool:
        return self.canUseRangeRequests

    def setOptions(self, options: dict) -> None:
        if "headers" in options:
            self.headers = options["headers"]
        if "clientProfile" in options:
            self.clientProfile = options["clientProfile"]
        if "userAgent" in options:
            self.userAgent = options["userAgent"]
        if "subworkerCount" in options:
            self.subworkerCount = _boundedSubworkerCount(options["subworkerCount"])
        if "trustedChecksum" in options:
            try:
                expected = parseTrustedChecksum(options["trustedChecksum"])
            except ValueError:
                expected = None
                self._invalidChecksumEntry = True
            else:
                self._invalidChecksumEntry = False
            self._expectedChecksumAlgorithm, self._expectedChecksumValue = expected or ("", "")

    @property
    def outputPath(self) -> str:
        return self.task.outputPath

    @property
    def recordPath(self) -> Path:
        return Path(f"{self.outputPath}.ghd")

    @property
    def validatorPath(self) -> Path:
        return self.recordPath.with_name(self.recordPath.name + ".meta")

    def _loadMetadata(self) -> dict | None:
        try:
            metadata = json.loads(self.validatorPath.read_text(encoding="utf-8"))
            if not isinstance(metadata, dict) or metadata.get("version") not in {1, 2}:
                return None
            return metadata
        except (OSError, ValueError, TypeError):
            return None

    def _loadValidator(self, url: str) -> HttpValidator | None:
        try:
            metadata = self._loadMetadata()
            if (metadata is None
                    or metadata.get("urlHash") != hashlib.sha256(url.encode()).hexdigest()):
                return None
            kind = metadata.get("kind")
            value = metadata.get("value")
            if kind not in {"etag", "last-modified"} or not isinstance(value, str):
                return None
            validator = HttpValidator(kind, value)
            expected = HttpValidator(kind, value)
            if _httpValidator({kind: value}) != expected:
                return None
            return validator
        except (OSError, ValueError, AttributeError, TypeError):
            return None

    def _loadExpectedChecksum(self) -> tuple[str, str] | None:
        metadata = self._loadMetadata()
        if metadata is None or metadata.get("version") != 2:
            return None
        expectedUrlHash = metadata.get("expectedUrlHash")
        if not isinstance(expectedUrlHash, str):
            raise TaskError("下载校验信息无效")
        if expectedUrlHash != hashlib.sha256(self.url.encode()).hexdigest():
            return None
        expected = metadata.get("expectedChecksum")
        if not isinstance(expected, dict):
            raise TaskError("下载校验信息无效")
        try:
            parsed = parseTrustedChecksum(
                f"{expected.get('algorithm', '')}:{expected.get('value', '')}"
            )
        except ValueError as error:
            raise TaskError("下载校验信息无效") from error
        if parsed is None:
            raise TaskError("下载校验信息无效")
        return parsed

    def saveExpectedChecksum(self) -> None:
        if self._invalidChecksumEntry:
            raise TaskError("下载校验信息无效")
        if not self._expectedChecksumAlgorithm:
            return
        metadata = {
            "version": 2,
            "expectedUrlHash": hashlib.sha256(self.url.encode()).hexdigest(),
            "expectedChecksum": {
                "algorithm": self._expectedChecksumAlgorithm,
                "value": self._expectedChecksumValue,
            },
        }
        if not self._writeMetadata(metadata):
            raise TaskError("无法保存下载校验值")

    def loadExpectedChecksum(self) -> None:
        expected = self._loadExpectedChecksum()
        if expected is not None:
            self._expectedChecksumAlgorithm, self._expectedChecksumValue = expected

    def _writeMetadata(self, metadata: dict) -> bool:
        tempPath = self.validatorPath.with_name(self.validatorPath.name + ".tmp")
        try:
            with open(tempPath, "w", encoding="utf-8") as metadataFile:
                json.dump(metadata, metadataFile, separators=(",", ":"))
                metadataFile.flush()
                os.fsync(metadataFile.fileno())
            tempPath.replace(self.validatorPath)
            return True
        except Exception as error:
            record_download_failure(self.url, error, event="resume_metadata_write_failed")
            logger.error("HTTP resume metadata write failed")
            with suppress(OSError):
                tempPath.unlink()
            return False

    def _saveValidator(self, url: str, validator: HttpValidator | None) -> bool:
        if self._expectedChecksumAlgorithm:
            expected = (self._expectedChecksumAlgorithm, self._expectedChecksumValue)
        else:
            expected = self._loadExpectedChecksum()
        if validator is None and expected is None:
            return False
        metadata = {"version": 2 if expected else 1}
        if validator is not None:
            metadata.update({
                "urlHash": hashlib.sha256(url.encode()).hexdigest(),
                "kind": validator.kind,
                "value": validator.value,
            })
        if expected is not None:
            metadata.update({
                "expectedUrlHash": hashlib.sha256(self.url.encode()).hexdigest(),
                "expectedChecksum": {"algorithm": expected[0], "value": expected[1]},
            })
        return self._writeMetadata(metadata)

    def _deleteValidator(self) -> None:
        for path in (self.validatorPath, self.validatorPath.with_name(self.validatorPath.name + ".tmp")):
            try:
                if path.is_file() or path.is_symlink():
                    path.unlink()
            except Exception as e:
                record_download_failure(self.url, e, event="resume_metadata_cleanup_failed")
                logger.error("HTTP resume metadata cleanup failed")

    async def _getTransferResponse(self, client, headers):
        response = await client.get(self._effectiveUrl, headers=headers)
        status = response.status.as_int()
        if status not in {401, 403, 404, 410} or self._effectiveUrl == self.url:
            return response

        response.close()
        refreshed = await client.get(self.url, headers=headers)
        refreshedStatus = refreshed.status.as_int()
        if (refreshedStatus in PERMANENT_STATUS
                or refreshed.headers.contains_key("cf-mitigated")):
            refreshed.close()
            raise PermanentDownloadError(refreshedStatus)
        if refreshedStatus == 206 and not _hasMatchingValidator(refreshed, self._activeValidator):
            refreshed.close()
            raise RangeNotSupportedError()
        if refreshedStatus not in {200, 206}:
            return refreshed
        if refreshedStatus == 206 and self._activeValidator is None:
            refreshed.close()
            raise RangeNotSupportedError()

        # Do not mix bytes from a refreshed redirect unless its validator
        # matches the representation observed during the initial probe.
        self._effectiveUrl = str(refreshed.url)
        return refreshed

    def _loadRecord(self) -> list[HttpSubworker]:
        if not self.recordPath.exists():
            return []
        try:
            data = self.recordPath.read_bytes()
            if not data or len(data) % 24:
                return []
            records = [unpack("<QQQ", data[i:i + 24]) for i in range(0, len(data), 24)]
            subworkers = []
            for index, (start, position, end) in enumerate(records):
                if position < start:
                    return []
                subworkers.append(HttpSubworker(
                    index=index, start=start, end=end,
                    receivedBytes=position - start,
                ))

            if self.fileSize > 0:
                cursor = 0
                for start, position, end in records:
                    if start != cursor or end < start or end >= self.fileSize or position > end + 1:
                        return []
                    cursor = end + 1
                if cursor != self.fileSize:
                    return []
                outputPath = Path(self.outputPath)
                if not outputPath.is_file() or outputPath.stat().st_size != self.fileSize:
                    return []
            else:
                if len(records) != 1 or records[0][0] != 0 or records[0][2] != SpecialFileSize.UNKNOWN:
                    return []
                outputPath = Path(self.outputPath)
                if records[0][1] and (not outputPath.is_file() or outputPath.stat().st_size < records[0][1]):
                    return []
            return subworkers
        except Exception as e:
            record_download_failure(self.url, e, event="resume_record_read_failed")
            logger.error("HTTP resume record read failed")
            return []

    def _buildSubworkers(self) -> list[HttpSubworker]:
        if not self.canUseRangeRequests:
            return [HttpSubworker(index=0, start=0, end=SpecialFileSize.NOT_SUPPORTED)]

        if self.fileSize <= 0:
            return [HttpSubworker(index=0, start=0, end=SpecialFileSize.UNKNOWN)]

        count = min(_boundedSubworkerCount(self.subworkerCount), self.fileSize)
        chunkSize = self.fileSize // count
        subworkers = []
        start = 0
        for i in range(count - 1):
            end = start + chunkSize - 1
            subworkers.append(HttpSubworker(index=i, start=start, end=end))
            start = end + 1
        subworkers.append(HttpSubworker(index=count - 1, start=start, end=self.fileSize - 1))
        return subworkers

    def _validateCompletedTransfer(self, fd: int) -> None:
        actualSize = os.fstat(fd).st_size
        if self.fileSize > 0:
            if actualSize != self.fileSize:
                raise InvalidTransferResponseError("final file size differs from the expected size")

            if self.canUseRangeRequests:
                cursor = 0
                for subworker in sorted(self.subworkers, key=lambda worker: worker.start):
                    if subworker.end < subworker.start:
                        if subworker.receivedBytes:
                            raise InvalidTransferResponseError("empty range worker has received bytes")
                        continue
                    expectedBytes = subworker.end - subworker.start + 1
                    if subworker.start != cursor or subworker.receivedBytes != expectedBytes:
                        raise InvalidTransferResponseError("range workers did not cover the complete file")
                    cursor = subworker.end + 1
                if cursor != self.fileSize:
                    raise InvalidTransferResponseError("range workers did not cover the complete file")
            elif sum(subworker.receivedBytes for subworker in self.subworkers) != self.fileSize:
                raise InvalidTransferResponseError("streamed bytes differ from the expected file size")
            return

        receivedBytes = sum(subworker.receivedBytes for subworker in self.subworkers)
        if actualSize != receivedBytes:
            raise InvalidTransferResponseError("final file size differs from the received byte count")

    def _updateExpectedRemoteFileSize(self, newSize: int) -> None:
        if self.httpByteOffset != 0 or self.fileSize <= 0 or newSize < 0 or newSize == self.fileSize:
            return

        oldSize = self.fileSize
        self.fileSize = newSize
        taskSize = getattr(self.task, "fileSize", 0)
        if taskSize > 0:
            self.task.fileSize = max(0, taskSize + newSize - oldSize)

    def _reconcileRemoteFileSize(self, newSize: int, fd: int) -> None:
        """Trust a valid full-resource Content-Range over a stale size probe."""
        if self.httpByteOffset != 0 or self.fileSize <= 0 or newSize <= 0 or newSize == self.fileSize:
            return

        oldSize = self.fileSize
        ftruncate(fd, newSize)
        self._updateExpectedRemoteFileSize(newSize)

        if newSize < oldSize:
            for subworker in self.subworkers:
                if subworker.start >= newSize:
                    subworker.end = subworker.start - 1
                    subworker.receivedBytes = 0
                    continue
                subworker.end = min(subworker.end, newSize - 1)
                subworker.receivedBytes = min(
                    subworker.receivedBytes,
                    max(0, subworker.end - subworker.start + 1),
                )
            return

        # Existing workers already cover [0, oldSize); let a new worker fetch the
        # newly discovered tail without throwing away successfully downloaded bytes.
        subworker = HttpSubworker(
            index=max((worker.index for worker in self.subworkers), default=-1) + 1,
            start=oldSize,
            end=newSize - 1,
        )
        self.subworkers.append(subworker)
        self._taskGroup.create_task(self._runSubworker(subworker, fd))

    def _outputTargetFingerprint(self, *, hasResumeArtifacts: bool) -> tuple | None:
        outputPath = Path(self.outputPath)
        try:
            info = os.lstat(outputPath)
        except FileNotFoundError:
            return None
        except OSError as error:
            raise _ioTaskError(error, preparing=True) from error

        if S_ISLNK(info.st_mode) or not S_ISREG(info.st_mode):
            raise TaskError("目标路径类型不安全，已保留现有内容")
        if info.st_size > 0 and not hasResumeArtifacts:
            raise TaskError("目标文件已存在，未覆盖")
        return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns)

    def _createSequentialStage(self) -> tuple[Path, int]:
        outputPath = Path(self.outputPath)
        mode = (self._outputFingerprint[2] & 0o777) if self._outputFingerprint else 0o666
        for _ in range(8):
            candidate = outputPath.with_name(
                f".{outputPath.name}.zflow-fallback-{uuid.uuid4().hex}.tmp"
            )
            try:
                fd = os.open(candidate, os.O_RDWR | os.O_CREAT | os.O_EXCL, mode)
                return candidate, fd
            except FileExistsError:
                continue
            except OSError as error:
                raise _ioTaskError(error, preparing=True) from error
        raise TaskError("无法准备下载文件")

    def _transferDiagnosticContext(self, fd: int | None = None) -> dict:
        context = {
            "expected_size": max(0, self.fileSize),
            "total_received": sum(worker.receivedBytes for worker in self.subworkers),
            "workers": [
                {
                    **worker.lastDiagnostics,
                    "worker_start": worker.start,
                    "worker_end": max(0, worker.end),
                    "worker_bytes": worker.receivedBytes,
                }
                for worker in self.subworkers[:32]
            ],
        }
        if fd is not None:
            try:
                context["actual_size"] = os.fstat(fd).st_size
            except OSError:
                pass
        return context

    def _recordTransferFailure(
        self,
        error: BaseException,
        *,
        subworker: HttpSubworker | None = None,
        event: str = "download_response_rejected",
        fd: int | None = None,
    ) -> None:
        context = self._transferDiagnosticContext(fd)
        if subworker is not None:
            context.update(subworker.lastDiagnostics)
            context.update({
                "worker_start": subworker.start,
                "worker_end": max(0, subworker.end),
                "worker_bytes": subworker.receivedBytes,
            })
        try:
            record_download_failure(self.url, error, context=context, event=event)
        except Exception:
            pass

    async def _retryTransfer(
        self, error: Exception, subworker: HttpSubworker, operation: str,
    ) -> None:
        subworker.consecutiveFailures += 1
        attempt = subworker.consecutiveFailures
        if attempt >= MAX_TRANSFER_ATTEMPTS:
            self._recordTransferFailure(
                error, subworker=subworker, event="download_retry_exhausted",
            )
            raise TaskError("服务器暂时无法提供文件，重试次数已用尽") from error

        self._recordTransferFailure(error, subworker=subworker, event="download_retry")
        delay = BASE_RETRY_DELAY * (2 ** (attempt - 1))
        logger.warning(
            "Transient HTTP {} failure; attempt {}/{}; retry delay {:.1f}s",
            operation, attempt, MAX_TRANSFER_ATTEMPTS, delay,
        )
        await asyncio.sleep(delay)

    def _beginSequentialFallback(self, error: BaseException) -> None:
        """Restart from byte zero in a staging file, preserving resume sidecars on failure."""
        self._recordTransferFailure(error, event="range_fallback")
        currentFingerprint = self._outputTargetFingerprint(hasResumeArtifacts=True)
        if currentFingerprint is None:
            raise TaskError("目标文件在下载期间已更改，已停止覆盖")
        try:
            descriptor = os.fstat(self._fd)
        except OSError as ioError:
            raise _ioTaskError(ioError, preparing=True) from ioError
        if (currentFingerprint[0], currentFingerprint[1]) != (descriptor.st_dev, descriptor.st_ino):
            raise TaskError("目标文件在下载期间已更改，已停止覆盖")

        stagePath, stageFd = self._createSequentialStage()
        try:
            os.close(self._fd)
        except OSError as ioError:
            os.close(stageFd)
            with suppress(OSError):
                stagePath.unlink()
            raise _ioTaskError(ioError, preparing=True) from ioError

        self._fallbackTargetFingerprint = currentFingerprint
        self._fd = stageFd
        self._fallbackStagePath = stagePath
        self._rangeFallbackActive = True
        self.canUseRangeRequests = False
        self.subworkers = self._buildSubworkers()

    def _commitSequentialFallback(self) -> None:
        if self._fallbackStagePath is None:
            return
        currentFingerprint = self._outputTargetFingerprint(hasResumeArtifacts=True)
        if currentFingerprint != self._fallbackTargetFingerprint:
            raise TaskError("目标文件在下载期间已更改，已保留现有内容")
        os.fsync(self._fd)
        os.close(self._fd)
        self._fd = -1
        try:
            if self._fallbackTargetFingerprint is None:
                # Exclusive hard-link creation prevents replacing a file that appeared
                # after the initial target check; both paths are in the same directory.
                os.link(self._fallbackStagePath, self.outputPath)
                self._fallbackStagePath.unlink()
            else:
                os.replace(self._fallbackStagePath, self.outputPath)
        except FileExistsError as error:
            raise TaskError("目标文件在下载期间已创建，已保留现有内容") from error
        except OSError as error:
            raise _ioTaskError(error) from error
        self._fallbackStagePath = None
        self._fallbackTargetFingerprint = None

    def _deleteRecord(self) -> None:
        try:
            if self.recordPath.is_file() or self.recordPath.is_symlink():
                self.recordPath.unlink()
        except Exception as e:
            record_download_failure(self.url, e, event="resume_record_cleanup_failed")
            logger.error("HTTP resume record cleanup failed")

    def _resetRecordForFreshRetry(self) -> None:
        """Invalidate byte coverage without deleting the resume sidecar."""
        try:
            with self.recordPath.open("wb") as recordFile:
                recordFile.flush()
                os.fsync(recordFile.fileno())
        except OSError as error:
            record_download_failure(self.url, error, event="resume_record_reset_failed")
            logger.error("HTTP resume record reset failed")
            raise TaskError("无法重置下载恢复记录") from error

    def _splitSlowest(self) -> HttpSubworker | None:
        slowest = max(self.subworkers, key=lambda sw: sw.end - sw.position + 1)
        remainingBytes = slowest.end - slowest.position + 1
        if remainingBytes < 2:
            return None

        base = remainingBytes // 2
        remainder = remainingBytes % 2
        oldEnd = slowest.end
        slowest.end = slowest.position + base + remainder - 1

        newSubworker = HttpSubworker(
            index=len(self.subworkers),
            start=slowest.end + 1,
            end=oldEnd,
        )
        self.subworkers.insert(self.subworkers.index(slowest) + 1, newSubworker)
        return newSubworker

    def _reassignSubworker(self) -> None:
        if self.fileSize <= 0:
            return
        slowest = max(self.subworkers, key=lambda sw: sw.end - sw.position + 1)
        if slowest.end - slowest.position + 1 < cfg.maxReassignSize.value * 1024:
            return
        newSw = self._splitSlowest()
        if newSw:
            now = time.monotonic()
            startAt = max(now, self._nextSplitStartAt)
            self._nextSplitStartAt = startAt + SPLIT_START_INTERVAL
            self._taskGroup.create_task(self._runSubworker(newSw, self._fd, delay=startAt - now))

    def _autoSpeedUp(self) -> None:
        if self.isAccelerated or not cfg.autoSpeedUp.value:
            return

        self._speedHistory.append(self.speed)
        if len(self._speedHistory) > 5:
            self._speedHistory.pop(0)
        if len(self._speedHistory) < 5:
            return

        avgSpeed = sum(self._speedHistory) / len(self._speedHistory)
        if avgSpeed == 0:
            return

        maxDeviation = max(abs(s - avgSpeed) / avgSpeed for s in self._speedHistory)
        if maxDeviation > 0.15:
            return

        if self._accelCheckTime == 0:
            self._accelInitialWorkers = len(self.subworkers)
            self._accelInitialSpeed = avgSpeed
            self._accelCheckTime = asyncio.get_running_loop().time()
            for _ in range(4):
                self._reassignSubworker()
        else:
            elapsed = asyncio.get_running_loop().time() - self._accelCheckTime
            if elapsed <= 5:
                return

            workerRatio = (len(self.subworkers) - self._accelInitialWorkers) / self._accelInitialWorkers
            speedRatio = (avgSpeed - self._accelInitialSpeed) / self._accelInitialSpeed

            if speedRatio < 0.8 * workerRatio:
                self.isAccelerated = True
                logger.info("自动加速已禁用，subworker 增加比: {:.2%}, 速度提升比: {:.2%}",
                            workerRatio, speedRatio)
            else:
                self._accelCheckTime = 0
                logger.info("继续自动加速，subworker 增加比: {:.2%}, 速度提升比: {:.2%}",
                            workerRatio, speedRatio)

    async def _supervise(self) -> None:
        try:
            self.receivedBytes = sum(sw.receivedBytes for sw in self.subworkers)
            while True:
                if self.canUseRangeRequests:
                    data = tuple(
                        val for sw in self.subworkers
                        for val in (sw.start, sw.position, sw.end)
                    )
                    tempPath = self.recordPath.with_name(self.recordPath.name + ".tmp")
                    try:
                        with open(tempPath, "wb") as recordFile:
                            recordFile.write(pack("<" + "Q" * len(data), *data))
                            recordFile.flush()
                            os.fsync(recordFile.fileno())
                        tempPath.replace(self.recordPath)
                    except Exception as e:
                        record_download_failure(self.url, e, event="progress_record_write_failed")
                        logger.error("HTTP progress record write failed")

                receivedBytes = sum(sw.receivedBytes for sw in self.subworkers)
                self.speed = receivedBytes - self.receivedBytes
                self.receivedBytes = receivedBytes
                if self.fileSize > 0:
                    self.progress = (receivedBytes / self.fileSize) * 100
                else:
                    self.progress = 0

                self._autoSpeedUp()
                await asyncio.sleep(1)
        except CancelledError:
            pass

    async def _runSubworker(self, subworker: HttpSubworker, fd: int, delay: float = 0) -> None:
        await asyncio.sleep(delay)
        if subworker.end == SpecialFileSize.UNKNOWN:
            while True:
                subworker.lastDiagnostics = {}
                client = buildClient(
                    emulation=self._emulation, userAgent=self.userAgent or None,
                    readTimeout=STREAM_READ_TIMEOUT, blockLocalRedirects=True,
                )
                try:
                    httpPos = self.httpByteOffset + subworker.position
                    requestedRange = f"bytes={httpPos}-"
                    subworker.lastDiagnostics = {"requested_range": requestedRange}
                    headers = {**self._effectiveHeaders, "range": requestedRange, "accept-encoding": "identity"}
                    if self._activeValidator:
                        headers["if-range"] = self._activeValidator.value
                    response = await self._getTransferResponse(client, headers)
                    responseDiagnostics = capture_http_response(
                        response, requested_range=requestedRange,
                    )
                    subworker.lastDiagnostics = responseDiagnostics
                    try:
                        status = response.status.as_int()
                        if status in PERMANENT_STATUS or response.headers.contains_key("cf-mitigated"):
                            raise PermanentDownloadError(status)
                        if self._remoteSizeChangedWithoutValidator:
                            raise RangeNotSupportedError()
                        if status == 200:
                            raise RangeNotSupportedError()
                        if status != 206:
                            _raiseUnexpectedHttpStatus(status)
                        expectedStart = self.httpByteOffset + subworker.position
                        actualStart, rangeEnd, total = _parseContentRange(response)
                        if not _matchesValidator(response, self._activeValidator):
                            raise RangeNotSupportedError()
                        if actualStart != expectedStart:
                            raise InvalidTransferResponseError("Content-Range start does not match the request")
                        receivedBefore = subworker.receivedBytes
                        responseBytes = 0
                        expectedResponseBytes = rangeEnd - actualStart + 1
                        async for chunk in response.stream():
                            if not chunk:
                                continue
                            remaining = rangeEnd - (self.httpByteOffset + subworker.position) + 1
                            if len(chunk) > remaining:
                                raise InvalidTransferResponseError("response body exceeds Content-Range")
                            _writeFully(fd, chunk, subworker.position)
                            subworker.receivedBytes += len(chunk)
                            responseBytes += len(chunk)
                            responseDiagnostics["bytes_received"] = responseBytes
                            self._reportSpeed(len(chunk))
                            await self._waitForSpeedLimit()
                    finally:
                        response.close()
                    if responseBytes != expectedResponseBytes:
                        raise InvalidTransferResponseError("range body length does not match Content-Range")
                    if subworker.receivedBytes == receivedBefore:
                        raise InvalidTransferResponseError("range response made no progress")
                    subworker.consecutiveFailures = 0
                    if total is not None and self.httpByteOffset + subworker.position < total:
                        continue
                    ftruncate(fd, subworker.receivedBytes)
                    return
                except CancelledError:
                    raise
                except (PermanentDownloadError, RangeNotSupportedError, InvalidTransferResponseError) as e:
                    self._recordTransferFailure(e, subworker=subworker)
                    raise
                except Exception as e:
                    if isinstance(e, OSError) and e.errno in FATAL_IO_ERRNO:
                        raise
                    await self._retryTransfer(e, subworker, "range request")
                finally:
                    client.close()

        elif subworker.end == SpecialFileSize.NOT_SUPPORTED:
            while True:
                subworker.lastDiagnostics = {}
                client = buildClient(
                    emulation=self._emulation, userAgent=self.userAgent or None,
                    readTimeout=STREAM_READ_TIMEOUT, blockLocalRedirects=True,
                )
                try:
                    ftruncate(fd, 0)
                    subworker.receivedBytes = 0
                    requestHeaders = {**self._effectiveHeaders, "accept-encoding": "identity"}
                    response = await self._getTransferResponse(client, requestHeaders)
                    responseDiagnostics = capture_http_response(response)
                    subworker.lastDiagnostics = responseDiagnostics
                    try:
                        status = response.status.as_int()
                        if status in PERMANENT_STATUS or response.headers.contains_key("cf-mitigated"):
                            raise PermanentDownloadError(status)
                        if status in {206, 416}:
                            raise InvalidTransferResponseError(
                                "full response unexpectedly returned a range-only status"
                            )
                        if status != 200:
                            _raiseUnexpectedHttpStatus(status)
                        if self._rangeFallbackActive:
                            contentLength = _headerValue(response.headers, "content-length")
                            if contentLength:
                                if not contentLength.isdecimal():
                                    raise InvalidTransferResponseError("invalid Content-Length")
                                self._updateExpectedRemoteFileSize(int(contentLength))
                        async for chunk in response.stream():
                            if not chunk:
                                continue
                            if self.fileSize > 0 and subworker.receivedBytes + len(chunk) > self.fileSize:
                                raise InvalidTransferResponseError("response exceeds the probed file size")
                            _writeFully(fd, chunk, subworker.receivedBytes)
                            subworker.receivedBytes += len(chunk)
                            responseDiagnostics["bytes_received"] = subworker.receivedBytes
                            self._reportSpeed(len(chunk))
                            await self._waitForSpeedLimit()
                        if self.fileSize > 0 and subworker.receivedBytes != self.fileSize:
                            raise InvalidTransferResponseError("response size differs from the probed file size")
                        subworker.consecutiveFailures = 0
                    finally:
                        response.close()
                    ftruncate(fd, subworker.receivedBytes)
                    return
                except CancelledError:
                    raise
                except (PermanentDownloadError, InvalidTransferResponseError) as e:
                    self._recordTransferFailure(e, subworker=subworker)
                    raise
                except Exception as e:
                    if isinstance(e, OSError) and e.errno in FATAL_IO_ERRNO:
                        raise
                    await self._retryTransfer(e, subworker, "full response")
                finally:
                    client.close()

        else:
            while subworker.position <= subworker.end:
                subworker.lastDiagnostics = {}
                client = buildClient(
                    emulation=self._emulation, userAgent=self.userAgent or None,
                    readTimeout=STREAM_READ_TIMEOUT, blockLocalRedirects=True,
                )
                try:
                    httpPos = self.httpByteOffset + subworker.position
                    httpEnd = self.httpByteOffset + subworker.end
                    requestedRange = f"bytes={httpPos}-{httpEnd}"
                    subworker.lastDiagnostics = {"requested_range": requestedRange}
                    headers = {
                        **self._effectiveHeaders,
                        "range": requestedRange,
                        "accept-encoding": "identity",
                    }
                    if self._activeValidator:
                        headers["if-range"] = self._activeValidator.value
                    response = await self._getTransferResponse(client, headers)
                    responseDiagnostics = capture_http_response(
                        response, requested_range=requestedRange,
                    )
                    subworker.lastDiagnostics = responseDiagnostics
                    try:
                        status = response.status.as_int()
                        if status in PERMANENT_STATUS or response.headers.contains_key("cf-mitigated"):
                            raise PermanentDownloadError(status)
                        if self._remoteSizeChangedWithoutValidator:
                            raise RangeNotSupportedError()
                        if status == 416 and self.httpByteOffset == 0:
                            actualSize = _parseUnsatisfiedContentRange(response)
                            if actualSize is not None and actualSize > 0:
                                if not _hasMatchingValidator(response, self._activeValidator):
                                    self._remoteSizeChangedWithoutValidator = True
                                    self._updateExpectedRemoteFileSize(actualSize)
                                    raise RangeNotSupportedError()
                                if actualSize > httpPos:
                                    raise InvalidTransferResponseError(
                                        "416 response contradicts the requested range"
                                    )
                                self._reconcileRemoteFileSize(actualSize, fd)
                                if subworker.start >= self.fileSize:
                                    subworker.end = subworker.start - 1
                                    subworker.receivedBytes = 0
                                    return
                                subworker.end = min(subworker.end, self.fileSize - 1)
                                continue
                        if status == 200:
                            raise RangeNotSupportedError()
                        if status != 206:
                            _raiseUnexpectedHttpStatus(status)
                        expectedStart = self.httpByteOffset + subworker.position
                        requestedEnd = self.httpByteOffset + subworker.end
                        actualStart, rangeEnd, total = _parseContentRange(response)
                        if actualStart != expectedStart or rangeEnd > requestedEnd:
                            raise InvalidTransferResponseError("Content-Range does not match the requested range")
                        sizeChanged = (
                            self.httpByteOffset == 0
                            and total is not None
                            and total > 0
                            and total != self.fileSize
                        )
                        if sizeChanged:
                            if not _hasMatchingValidator(response, self._activeValidator):
                                self._remoteSizeChangedWithoutValidator = True
                                self._updateExpectedRemoteFileSize(total)
                                raise RangeNotSupportedError()
                            self._reconcileRemoteFileSize(total, fd)
                        elif not _matchesValidator(response, self._activeValidator):
                            raise RangeNotSupportedError()
                        elif total is not None and total <= requestedEnd:
                            if (self.httpByteOffset == 0 and total == self.fileSize
                                    and rangeEnd == total - 1):
                                subworker.end = min(subworker.end, total - 1)
                            else:
                                raise InvalidTransferResponseError("Content-Range does not match the requested range")
                        receivedBefore = subworker.receivedBytes
                        async for chunk in response.stream():
                            if not chunk:
                                continue
                            responseRemaining = rangeEnd - (self.httpByteOffset + subworker.position) + 1
                            if len(chunk) > responseRemaining:
                                raise InvalidTransferResponseError("response body exceeds Content-Range")
                            workerRemaining = subworker.end - subworker.position + 1
                            if workerRemaining <= 0:
                                break
                            if len(chunk) > workerRemaining:
                                chunk = chunk[:workerRemaining]
                            _writeFully(fd, chunk, subworker.position)
                            subworker.receivedBytes += len(chunk)
                            responseDiagnostics["bytes_received"] = (
                                responseDiagnostics.get("bytes_received", 0) + len(chunk)
                            )
                            self._reportSpeed(len(chunk))
                            await self._waitForSpeedLimit()
                            if subworker.position > subworker.end:
                                break
                    finally:
                        response.close()

                    if subworker.position > subworker.end:
                        subworker.receivedBytes = subworker.end - subworker.start + 1
                    elif subworker.receivedBytes == receivedBefore:
                        raise InvalidTransferResponseError("range response made no progress")
                    subworker.consecutiveFailures = 0

                except CancelledError:
                    raise
                except (PermanentDownloadError, RangeNotSupportedError, InvalidTransferResponseError) as e:
                    self._recordTransferFailure(e, subworker=subworker)
                    raise
                except Exception as e:
                    if isinstance(e, OSError) and e.errno in FATAL_IO_ERRNO:
                        raise
                    await self._retryTransfer(e, subworker, "range request")
                finally:
                    client.close()

            self._reassignSubworker()

    async def run(self, reportSpeed, waitForSpeedLimit) -> None:
        if self._invalidChecksumEntry:
            raise TaskError("下载校验信息无效")
        self._remoteSizeChangedWithoutValidator = False
        self._reportSpeed = reportSpeed
        self._waitForSpeedLimit = waitForSpeedLimit
        self._speedHistory: list[int] = []
        self._accelCheckTime = 0
        self._nextSplitStartAt = 0
        shouldDeleteRecord = False
        resumeArtifactsPresent = self.recordPath.exists() or self.validatorPath.exists()
        self._outputFingerprint = self._outputTargetFingerprint(
            hasResumeArtifacts=resumeArtifactsPresent,
        )

        self._effectiveHeaders = {**self.headers}
        if self.userAgent and not any(k.lower() == "user-agent" for k in self.headers):
            self._effectiveHeaders["user-agent"] = self.userAgent

        self._emulation = toEmulation(self.clientProfile or cfg.clientProfile.value, "")

        probeHeaders = {**self._effectiveHeaders, "range": "bytes=0-0", "accept-encoding": "identity"}
        client = buildClient(
            emulation=self._emulation, userAgent=self.userAgent or None, timeout=30,
            blockLocalRedirects=True,
        )
        try:
            response = await client.get(self.url, headers=probeHeaders)
            try:
                status = response.status.as_int()
                if status in PERMANENT_STATUS:
                    raise TaskError("服务器返回了错误（{status}）", status=status)
                self._effectiveUrl = str(response.url)
                self._activeValidator = _httpValidator(response.headers)
            finally:
                response.close()
        finally:
            client.close()

        storedExpected = self._loadExpectedChecksum()
        if not self._expectedChecksumAlgorithm and storedExpected is not None:
            self._expectedChecksumAlgorithm, self._expectedChecksumValue = storedExpected

        restored = False
        recordExisted = self.recordPath.exists()
        storedValidator = self._loadValidator(self.url)
        if storedValidator is None and self._effectiveUrl != self.url:
            # Accept sidecars written by releases that keyed validators to the
            # final redirect target instead of the stable source URL.
            storedValidator = self._loadValidator(self._effectiveUrl)
        if (self.canUseRangeRequests and recordExisted and self._activeValidator
                and storedValidator == self._activeValidator):
            loaded = self._loadRecord()
            if loaded:
                self.subworkers = loaded
                restored = True

        if not restored:
            # Keep prior resume sidecars until a complete, verified transfer
            # succeeds; failed restarts must not erase recovery evidence.
            if self.canUseRangeRequests or self._expectedChecksumAlgorithm:
                saved = self._saveValidator(self.url, self._activeValidator)
                if self._expectedChecksumAlgorithm and not saved:
                    raise TaskError("无法保存下载校验值")
            self.subworkers = self._buildSubworkers()
        elif self.fileSize > 0:
            target = min(_boundedSubworkerCount(self.subworkerCount), self.fileSize)
            while len(self.subworkers) < target:
                if not self._splitSlowest():
                    break

        currentFingerprint = self._outputTargetFingerprint(
            hasResumeArtifacts=resumeArtifactsPresent,
        )
        if currentFingerprint != self._outputFingerprint:
            raise TaskError("目標文件在下載開始前已更改，已保留現有內容")
        if not self.canUseRangeRequests:
            self._fallbackTargetFingerprint = currentFingerprint
            self._fallbackStagePath, self._fd = self._createSequentialStage()
        else:
            openMode = os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
            if currentFingerprint is None:
                openMode |= os.O_CREAT | os.O_EXCL
            try:
                self._fd = os.open(self.outputPath, openMode, 0o666)
            except OSError as e:
                raise _ioTaskError(e, preparing=True) from e

        try:
            if not restored and self.canUseRangeRequests:
                ftruncate(self._fd, 0)
            if not restored and self.fileSize > 0:
                ftruncate(self._fd, self.fileSize)
        except OSError as e:
            os.close(self._fd)
            raise _ioTaskError(e, preparing=True) from e

        try:
            while True:
                supervisor = asyncio.create_task(self._supervise())
                try:
                    self._taskGroup = TaskGroup()
                    async with self._taskGroup:
                        for subworker in self.subworkers:
                            self._taskGroup.create_task(self._runSubworker(subworker, self._fd))

                    try:
                        self._validateCompletedTransfer(self._fd)
                    except InvalidTransferResponseError as error:
                        self._recordTransferFailure(error, event="range_integrity_failure", fd=self._fd)
                        if self.canUseRangeRequests:
                            self._beginSequentialFallback(error)
                            self._speedHistory.clear()
                            self._accelCheckTime = 0
                            continue
                        raise TaskError("服务器返回了不一致的范围或文件大小") from error

                    if self._expectedChecksumAlgorithm:
                        checksumPath = self._fallbackStagePath or Path(self.outputPath)
                        actual = await toChecksum(
                            checksumPath, self._expectedChecksumAlgorithm, lambda _: None,
                        )
                        if not hmac.compare_digest(actual, self._expectedChecksumValue):
                            self._resetRecordForFreshRetry()
                            algorithmName = {
                                "sha256": "SHA-256",
                                "sha512": "SHA-512",
                            }[self._expectedChecksumAlgorithm]
                            raise TaskError(
                                "下载校验失败（{algorithm}）：期望 {expected}，实际 {actual}",
                                algorithm=algorithmName,
                                expected=self._expectedChecksumValue,
                                actual=actual,
                            )

                    self._commitSequentialFallback()
                    shouldDeleteRecord = True
                    break
                except CancelledError:
                    self.setStatus(TaskStatus.PAUSED)
                    raise
                except ExceptionGroup as eg:
                    invalidRange = next(
                        (error for error in eg.exceptions
                         if isinstance(error, InvalidTransferResponseError)), None,
                    )
                    unsupportedRange = next(
                        (error for error in eg.exceptions
                         if isinstance(error, RangeNotSupportedError)), None,
                    )
                    fatalIo = next(
                        (error for error in eg.exceptions
                         if isinstance(error, OSError) and error.errno in FATAL_IO_ERRNO), None,
                    )
                    permanent = next(
                        (error for error in eg.exceptions if isinstance(error, PermanentDownloadError)), None,
                    )
                    if fatalIo is not None:
                        raise _ioTaskError(fatalIo) from eg
                    if permanent is not None:
                        raise TaskError("服务器返回了错误（{status}）", status=permanent.status) from eg

                    rangeFailure = invalidRange or unsupportedRange
                    if self.canUseRangeRequests and rangeFailure is not None:
                        self._beginSequentialFallback(rangeFailure)
                        self._speedHistory.clear()
                        self._accelCheckTime = 0
                        continue
                    if invalidRange is not None:
                        self._recordTransferFailure(invalidRange, event="range_integrity_failure", fd=self._fd)
                        raise TaskError("服务器返回了不一致的范围或文件大小") from eg

                    cause = eg.exceptions[0]
                    if isinstance(cause, PermanentDownloadError):
                        raise TaskError("服务器返回了错误（{status}）", status=cause.status) from eg
                    if isinstance(cause, OSError) and cause.errno in FATAL_IO_ERRNO:
                        raise _ioTaskError(cause) from eg
                    raise cause from eg
                finally:
                    if not supervisor.done():
                        supervisor.cancel()
                        with suppress(CancelledError):
                            await supervisor
        finally:
            if self._fd >= 0:
                os.close(self._fd)
            if self._fallbackStagePath is not None:
                with suppress(OSError):
                    self._fallbackStagePath.unlink()
                self._fallbackStagePath = None
            if shouldDeleteRecord:
                self._deleteRecord()
                self._deleteValidator()
                if cfg.shouldPreserveLastModified.value and self.lastModified:
                    try:
                        from email.utils import parsedate_to_datetime
                        mtime = parsedate_to_datetime(self.lastModified).timestamp()
                        os.utime(self.outputPath, (mtime, mtime))
                    except Exception as e:
                        record_download_failure(self.url, e, event="file_timestamp_update_failed")
                        logger.warning("Downloaded file timestamp update failed")
