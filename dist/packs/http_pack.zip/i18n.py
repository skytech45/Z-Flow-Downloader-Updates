from app.i18n import N

N("TaskErrors", "服务器返回了错误（{status}）")
N("TaskErrors", "磁盘空间不足")
N("HttpDraftCard", "可选 SHA-256 / SHA-512 校验值")
N("HttpDraftCard", "输入 64 或 128 个十六进制字符，可选 sha256: 或 sha512: 前缀")
N("HttpDraftCard", "SHA-256 需要 64 位十六进制字符，SHA-512 需要 128 位。")
